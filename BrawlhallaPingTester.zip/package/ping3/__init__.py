from .ping3 import ping
from .errors import *